# Simple Python Quiz
Run: python main.py
