questions=[
("Capital of Pakistan?","Islamabad"),
("2+2?","4"),
("Python creator?","Guido van Rossum")
]
score=0
for q,a in questions:
    ans=input(q+" ")
    if ans.strip().lower()==a.lower():
        print("Correct")
        score+=1
    else:
        print("Wrong. Answer:",a)
print(f"Score: {score}/{len(questions)}")
